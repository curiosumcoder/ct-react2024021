//export const dynamic = 'force-static'
import Image from "next/image";
import styles from "./page.module.css";

export default function Home() {
  const fe = () => {throw new Error("Not implemented.") };
  //fe();

  return (
    <main>
    </main>
  );
}

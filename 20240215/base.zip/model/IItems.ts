export default interface IItems<T>
{
    items: Array<T>
}